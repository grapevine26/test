from crawler_AML.crawler.AML_wordUsageChecker.Word_Usage_Comparing_checker_AML import wordUsage_checker
from crawler_AML.crawler.AML_wordUsageChecker.dbConnector_AML import dbConnector_AML_for_WordsUsage

class wordComparer:

    def __init__(self):
        print()