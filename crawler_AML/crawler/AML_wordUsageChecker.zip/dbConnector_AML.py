#!/usr/bin/python
import pymysql

class dbConnector_AML_for_WordsUsage():
    def __init__(self):
        try:
            self.connection = pymysql.connect(host='uml.kr', port=3366,
                                              user='aster_dba', password='!aster716811',
                                              db='aster', charset='utf8')

            self.connection.autocommit = True
            self.cursor = self.connection.cursor()

            print('DB connection completed')
        except Exception as e:
            print('Cannot connect to Database', e)


    #alqaeda
    def dataSelect_AML_Emotionalwords_alqaeda(self):
        try:
            sql_insert_query = """SELECT name, name_originalScript, nationality, address  FROM AML_alqaedaent_List;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultlist = []

            for b in a:
                result = ''.join(b)
                resultlist.append(result.replace('\ufeff', '').replace('\r','').replace('Title:', ''))
                #print(''.join(b) +',' + str(testCnt)) # join 한 값이 찍히지 않음.

            return resultlist

        except BaseException as e:
            print('data selection occured exception', e)
            return None

    #alqaeda
    def dataSelect_AML_Emotionalwords_alqaeda_dict(self):
        try:

            sql_insert_query = """SELECT name, name_originalScript, nationality  FROM AML_alqaedaent_List;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)

            print("Record selected successfully into AML_FBI_wantedList table")

            a = self.cursor.fetchall()

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultNamelist = []
            resultNameOriginalList = []
            resultNationalityList = []
            # resultDict = []

            for b in a:
                #result = ''.join(b)
                #resultlist.append(result.replace('\ufeff', '').replace('\r','').replace('Title:', ''))
                #print(''.join(b) +',' + str(testCnt)) # join 한 값이 찍히지 않음.

                #resultDict.append({'name':b[0], 'name_originalScript':str(b[1]).replace('Title:na', ''), 'nationality':str(b[2]).replace(')"', '')})
                resultNamelist.append(str(b[0]).replace('1: ', '').replace('2: ', '').replace('3: ', '').replace('4: ', '').replace('  ', ' ')
                                      .replace("'", "").replace('na', '').replace('\ufeff', ''))
                resultNameOriginalList.append(str(b[1]).replace('Title:na', '').replace('A.k.a.:', '').replace('F.k.a: ', '').replace('F.k.a. ', '')
                                              .replace('na', 'N/A').replace(' a)', 'a)').replace('.a)','a)').replace('"', ''))
                resultNationalityList.append(str(b[2]).replace(')"', '').replace(' na', 'N/A').replace('na ', 'N/A').replace('"', ''))

            return resultNamelist, resultNameOriginalList, resultNationalityList

        except BaseException as e:
            print('data selection occured exception', e)
            return None

    #FBI_wantedList
    def dataSelect_AML_Emotionalwords_FBI_wantedList(self):
        try:
            sql_insert_query = """SELECT suspectName, suspectCategories FROM AML_FBI_wantedList;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultsuspectNamelist = []
            resultsuspectCategoriesList = []

            for b in a:
                #resultDict.append({'suspectName':b[0], 'suspectCategories':str(b[1])})
                resultsuspectNamelist.append(str(b[0]).replace('\ufeff', ''))
                resultsuspectCategoriesList.append(b[1])

            return resultsuspectNamelist, resultsuspectCategoriesList

        except BaseException as e:
            print('data selection occured exception', e)
            return None

    # Interpol_wantedList
    def dataSelect_AML_Emotionalwords_Interpol_wantedList(self):
        try:
            sql_insert_query = """SELECT wanted_foreName, wanted_name, wanted_nationalities, wanted_image_href FROM AML_Interpol_wantedList;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultwanted_foreNamelist = []
            resultwanted_nameList = []
            resultwanted_nationalitiesList = []
            resultwanted_image_hrefList = []

            for b in a:
                resultwanted_foreNamelist.append(str(b[0]).replace('\ufeff', ''))
                resultwanted_nameList.append(b[1])
                resultwanted_nationalitiesList.append(b[2])
                resultwanted_image_hrefList.append(b[3])

            return resultwanted_foreNamelist, resultwanted_nameList, resultwanted_nationalitiesList, resultwanted_image_hrefList

        except BaseException as e:
            print('data selection occured exception', e)
            return None

    # Jurisdiction_bank_list
    def dataSelect_AML_Emotionalwords_Jurisdiction_bank_list(self):
        try:
            sql_insert_query = """SELECT bank_name, DATE_makingRule FROM AML_Jurisdictions_BankLists;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultbank_name = []
            resultDATE_makingRule = []

            for b in a:
                resultbank_name.append(str(b[0]).replace('\ufeff', ''))
                resultDATE_makingRule.append(b[1])

            return resultbank_name, resultDATE_makingRule


        except BaseException as e:
            print('data selection occured exception', e)
            return None


    # AML_OFAC_SDN
    def dataSelect_AML_OFAC_SDNList(self):
        try:
            sql_insert_query = """SELECT row01 AS nameForSanction, row02 AS categories, row03 AS nationalityForSanction, row04 AS detailDescript FROM AML_OFAC_SDN;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultNameForSanction = []
            resultCategories = []
            resultNationalityForSanction = []
            resultDetailDescript = []

            for b in a:
                resultNameForSanction.append(str(b[0]).replace('\ufeff', '').replace('Title:na', '').replace('A.k.a.:', '').replace('F.k.a: ', '').replace('F.k.a. ', '')
                                              .replace('na', 'N/A').replace(' a)', 'a)').replace('.a)','a)').replace('"', '').replace('  ', ' ').replace('-0- ', 'N/A'))
                resultCategories.append(str(b[1]).replace('-0- ', 'N/A'))
                resultNationalityForSanction.append(str(b[2]).replace('-0- ', 'N/A'))
                resultDetailDescript.append(str(b[3]).replace('-0- ', 'N/A'))

            return resultNameForSanction, resultCategories, resultNationalityForSanction, resultDetailDescript

        except BaseException as e:
            print('data selection occured exception', e)
            return None



    #Emotional Word List
    # Hazardous_list
    def dataSelect_AML_Emotionalwords_Hazardous_list(self):
        try:
            sql_insert_query = """SELECT word_EN, word_KR FROM AML_Hazardous_wordList;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultHazardousWord_EN = []
            resultHazardousWord_KR = []

            for b in a:
                resultHazardousWord_EN.append(str(b[0]).replace('\ufeff', ''))
                resultHazardousWord_KR.append(str(b[1]).replace('\r', ''))

            return resultHazardousWord_EN, resultHazardousWord_KR

        except BaseException as e:
            print('data selection occured exception', e)
            return None

    # AML_Related_wordList
    def dataSelect_AML_Related_wordList(self):
        try:
            sql_insert_query = """SELECT relatedWord_EN, relatedWord_KR FROM AML_Related_WordList;"""
            print(sql_insert_query)

            self.cursor.execute(sql_insert_query)
            a = self.cursor.fetchall()
            print("Record selected successfully into AML_FBI_wantedList table")

            self.connection.commit()  # 이거 안하면 데이터 안들어간다. DB에 연결됐어도..
            self.cursor.close()
            self.connection.close()

            resultRelatedWord_EN = []
            resultRelatedWord_KR = []

            for b in a:
                resultRelatedWord_EN.append(str(b[0]).replace('\ufeff', ''))
                resultRelatedWord_KR.append(str(b[1]).replace('\r', ''))

            return resultRelatedWord_EN, resultRelatedWord_KR

        except BaseException as e:
            print('data selection occured exception', e)
            return None


